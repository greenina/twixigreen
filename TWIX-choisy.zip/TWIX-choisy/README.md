# Igreen

**CS374 HCI team TWIX Design Project**

This repository contains Design Project Reports of Team TWIX in 2021 Spring Human-Computer-Interaction course(CS374) of KAIST School of Computing

Gyewon Kim(20190061),Inhwa Song(20190325),Taeyang Yoon(20190432),Seungyeon Choi(20190656)



This service is for newcomers of eco-friendly product consumption which supports them to be supported in continuously being motivated to the environment without being discouraged by personal gain(price, functionality, etc)



## Page description



### Main Page

The main page of the website. Here, you can see four pictures of parts of home(living room, dining room, bathroom, ) including several households. Some of them are drawn and overlaid on the picture, and some are not. If you click the drawn households, it links to Category Page showing related products. Furthermore, you can directly move to MyPage and each Category Pages of Living, Kitchen, Bathroom, Bedroom through NavBar on the top. 

### Category Page

ing~~

### Detail Page

ing~

<h3>My Page</h3>

ing~~